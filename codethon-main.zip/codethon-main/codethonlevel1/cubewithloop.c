#include <stdio.h>

int main()
{
    int n,cube;
    {
        printf("enter the no.");
        scanf("%d",&n);

        for(int i=1,i<n,i++)
        {
            //cube=n*n*n;
            //mult=cube;
            printf("enter the cube:"i,i,i*i*i);
        }
    }
}