#include <stdio.h>

int main(){
    int ch,area,pi=3.14,l,b,c,r;
    printf("enter the integer");
    scanf("%d",&ch);

    switch(ch)
    {
        case 11:
               area=pi*r*r;
               printf("area of circle:",area);
               break;
        case 22:
               area=l*b;
               printf("area of rectangle:",area);
               break;
        case 33:
               area=l*l*l*l;
               printf("area of the square:");
               break;
        case 44:
                area=                    
    }

}