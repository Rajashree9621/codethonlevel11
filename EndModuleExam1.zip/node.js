
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database!');
  
  connection.query('SELECT * FROM your_table', (error, results, fields) => {
    if (error) throw error;
    console.log('Data received from MySQL:');
    console.log(results);
  });
});

connection.end();