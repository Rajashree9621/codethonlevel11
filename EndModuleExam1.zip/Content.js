import { useState } from "react";

export function Content(props)
         const [name,setName]=useState()
         const[num1,setNum1]=useState(0);
         const[num2,setNum2]=useState(0);
         const[num3,setNum3]=useState();

         function addition(){
            setAdd(num1+num2);
         }

{
    return(
        <div>
            <div className="alert alert-light" 
            style={{height:"70vh",backgroundColor:"navy",color:"white"}}>

                <div className="alert alert-primary">
                    <input type="number" value={num1} onChange={function(event){
                        setNum1(parseInt(event.target.value))
                    }} />
                    <input type="number" value={num2} onChange={function(event){
                        setNum2(parseInt(event.target.value))
                    }} />
                </div>
               <p>This is Content..
                My name is RItu...
                I love my self.
                Muze khudme sab dikhta h yara m kya kru...!!
                </p> 
                <h1>{name}</h1>
                <input type="text" value={name} onChange={function()
                {
                    setName(event.target.value)

                }} />

                <button className="btn btn-success" onClick={function(){
                  setAdd(num1+num2);
                       }}> 
                       +</button>

                <h1>{add}</h1>

                <button className="btn btn-info" onClick={function(){
                    props.printName(name)
                }}>Your Name</button>
            </div>
        </div>
    )
}