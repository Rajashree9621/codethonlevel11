#include<stdio.h>
int main()
{
    char str[20];
    printf("Enter any string: ");
    scanf("%s",&str);

    printf("\n string is %s,str");
}