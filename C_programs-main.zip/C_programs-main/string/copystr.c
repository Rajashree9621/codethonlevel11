#include<stdio.h>
#include<string.h>
int main()
{
    char a[]="Rajashree Patil.";
    char b[50];
    strcpy(b,a);
    printf("string\t%s",b);
}