#include <stdio.h>
int main()
{
    int num;
    //printf("enter the no.");
    //scanf("%d",&num);

    for(int i=1;i<=10;i++)
    {
          if(i%2==0)
          printf("%d even\n",i);
    }
}