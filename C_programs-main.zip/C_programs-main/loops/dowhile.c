#include <stdio.h>
int main()
{
    int i=1;
    do
    {
           printf("%d\n print the no: ",i);
           i++;
    }
    while(i<=10);
    return 0;
    
}