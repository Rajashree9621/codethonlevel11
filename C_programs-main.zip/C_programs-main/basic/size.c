#include <stdio.h>
int main()
{
    int i;
    float f;
    char c;
    double d;

    printf("size of int: %d\n",sizeof(i));
    printf("size of float: %d\n",sizeof(f));
    printf("size of char:%d \n",sizeof(c));
    printf("size of doublr:%d ",sizeof(d));
}