#include <stdio.h>
 int main()
 {
    int fahrenhet,celcius;
    printf("enter fahrenhet value::");
    scanf("%d",&fahrenhet);

    celcius=(fahrenhet-32)/1.8;
    printf("celcius= %d",celcius);
    
    
 }