#include <stdio.h>
int main()
{
    //for(int i=10;i>=1;i--)    //reverce print 10 to 1
      for(int i=1;i<=10;i++)
    {
        printf("%d\t",i);
    }
}