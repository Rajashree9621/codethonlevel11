#include<stdio.h>
void add(void){

    int a,b;
    a=10,b=20;
    printf("Addition of 2 no. is %d",a+b);

}
int main()
{
    add();
}

