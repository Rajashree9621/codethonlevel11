#include <stdio.h>

int main()
{
    int n,d,sum=0;
    printf("enter values of n::");
    scanf("%d",&n);

    while(n>0)
    {
        d=n%10;
        n=n/10;
        sum=d+sum;
    }
    printf("sum of digits:: %d",sum);


     



}