#include <stdio.h>

int main()
{
    char c;
    printf("enter character: ");
    scanf("%c",&c);

    printf("ASCII value of %c= %d",c,c);
}