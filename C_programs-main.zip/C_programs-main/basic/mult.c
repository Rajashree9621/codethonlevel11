#include <stdio.h>

int main()
{
    int p,r,n,mult;
    printf(" enter the values of mult: ");
    scanf("%d%d%d",&p,&r,&n);
    mult = p*r*n;
    printf("%d",mult);

}