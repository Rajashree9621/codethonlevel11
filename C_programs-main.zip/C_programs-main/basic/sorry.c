#include<stdio.h>
int main()
{
    
    //printf("enter the word...");
    //scanf("%d",&num);
    for(int i=1;i<=100;i++)
    {
        
        if(i==65)
            continue;
        
        printf("%d\t",i);
    }
}