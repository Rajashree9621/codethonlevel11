#include<stdio.h>
int main()
{
    int x,y,z;
    
    printf("\n Addition of two no:\n ");
   // printf("substract two no: ");
    scanf("%d%d",&x,&y);
    z = x + y;
   // z = x - y;
    printf("%d",z);
    return 0;

}