#include<stdio.h>
int fact(int);

int main()
{
    int b,a=3;
    b=fact(a);
    printf("%d",b);
}
int fact(int i){
    int=
}