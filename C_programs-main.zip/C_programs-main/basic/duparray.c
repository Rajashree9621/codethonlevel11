#include <stdio.h>

int main()
{
    int arr[10],i,j,k;

    printf("enter elements of array %d");
    scanf("%d"&arr[10]);
}