#include<stdio.h>
void add(void);
int main()
{
    add();
}
void add(void)
{
    int a=20,b=30;
    printf("addition=%d",a+b);
}