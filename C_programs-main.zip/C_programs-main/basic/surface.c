#include <stdio.h>

int main()
{
    int  pi=3.14,r,h,surface_of_cylinder;
    printf("enter the values:");
    scanf("%d%d",&r,&h);

    surface_of_cylinder=2*pi*r*h;
    printf("%d",surface_of_cylinder);
    

}