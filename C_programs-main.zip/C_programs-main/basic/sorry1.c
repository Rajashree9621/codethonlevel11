#include<stdio.h>
int main()
{
    int i=1;
    do{
        if(i==65){
            i++;
            continue;
        }
            
        printf("\t %d",i);
        i++;
    }
    while(i<=100);
        
        
        
        
    
    
}